package ru.dataart.academy.java.figures;

public abstract class Figure {
    public abstract double getArea();

    public abstract double getPerimeter();
}
